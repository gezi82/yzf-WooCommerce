<?php
include_once("inc/easypay.config.php");
if (isset($_GET['para']))
{
	$para = json_decode($_GET['para'], true);
	$alipay_gateway_new = $alipay_config['apiurl'].'submit.php?';
	$sHtml = "<form id='alipaysubmit' name='alipaysubmit' action='".$alipay_gateway_new."_input_charset=".trim(strtolower($alipay_config['input_charset']))."' method='".$method."'>";
	while (list ($key, $val) = @each ($para))
	{
        $sHtml.= "<input type='hidden' name='".$key."' value='".$val."'/>";
    }
	//submit按钮控件请不要含有name属性
    $sHtml = $sHtml."<input type='submit' value='正在跳转'></form>";
	$sHtml = $sHtml."<script>document.forms['alipaysubmit'].submit();</script>";
	echo $sHtml;
}
?>