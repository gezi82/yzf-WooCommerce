<?php 
//过滤脚本提醒
date_default_timezone_set('PRC'); //时区设置 解决某些机器报错

$codepay_id = "";
$codepay_key = "";
$return_url = "";
//***************以上行号请勿更改*************//

$host = (isHTTPS() ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'];
$data = array(

	"id" => (int)$codepay_id,
    "key" => $codepay_key,
	//"pay_id" => $order_id,
	//"type" => $type,//1支付宝支付 3微信支付 2QQ钱包
    //"price" => $price,//金额100元
    "chart" => strtolower('utf-8'),
    "param" => "www.mebi.me",//自定义参数
    "outTime"=> 500,//二维码超时设置，默认6分钟
    "min"=> 0.01,//最低支付限制1分
    "user_ip" => getIp(),//付款人Ip
    "pay_type"=> 0,//启用支付宝官方接口 会员版授权后生效
    //"user"=> "admin",//默认付款用户为admin
    //"userOff"=> false,//付款页面显示用户名
    //"notify_url"=>$host."/wc-api/wc_gateway_codepay",//通知地址
    "gateway"=> "http://api2.fateqq.com:52888/creat_order/?",//支付网关地址
    //"host"=> (isHTTPS() ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'], //获取域名
    "return_url"=>"",//跳转地址
    
    "go_time"=> 3,

);

//echo $data['notify_url'];

function create_link($params, $codepay_key, $host="")
{

    ksort($params); //重新排序$data数组
    reset($params); //内部指针指向数组中的第一个元素
    $sign = '';
    $urls = '';
    foreach ($params as $key => $val) {
        if ($val == '') continue;
        if ($key != 'sign') {
            if ($sign != '') {
                $sign .= "&";
                $urls .= "&";
            }
            $sign .= "$key=$val"; //拼接为url参数形式
            $urls .= "$key=" . urlencode($val); //拼接为url参数形式
        }
    }

    $key = md5($sign . $codepay_key);//开始加密
    $query = $urls . '&sign=' . $key; //创建订单所需的参数
    $apiHost = ($host ? $host : "http://api2.fateqq.com:52888/creat_order/?"); //网关
    $url = $apiHost . $query; //生成的地址
    return $url;
}


function isHTTPS()
{
    if (defined('HTTPS') && HTTPS) return true;
    if (!isset($_SERVER)) return FALSE;
    if (!isset($_SERVER['HTTPS'])) return FALSE;
    if ($_SERVER['HTTPS'] === 1) {  //Apache
        return TRUE;
    } elseif ($_SERVER['HTTPS'] === 'on') { //IIS
        return TRUE;
    } elseif ($_SERVER['SERVER_PORT'] == 443) { //其他
        return TRUE;
    }
    return FALSE;
}

//获取客户端IP地址
function getIp()
{ //取IP函数
    static $realip;
    if (isset($_SERVER)) {
        if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $realip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $realip = isset($_SERVER['HTTP_CLIENT_IP']) ? $_SERVER['HTTP_CLIENT_IP'] : $_SERVER['REMOTE_ADDR'];
        }
    } else {
        if (getenv('HTTP_X_FORWARDED_FOR')) {
            $realip = getenv('HTTP_X_FORWARDED_FOR');
        } else {
            $realip = getenv('HTTP_CLIENT_IP') ? getenv('HTTP_CLIENT_IP') : getenv('REMOTE_ADDR');
        }
    }
    return $realip;
}
 ?>