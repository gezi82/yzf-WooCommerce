<blockquote class="layui-elem-quote layui-quote-nm">为了保护你的支付安全，此处暂不支持添加修改通知地址，如需修改请登录codepay<button class="layui-btn layui-btn-sm layui-btn-primary" id="codepayback">后台</button></blockquote>
<div class="layui-card">
	<div class="layui-card-header">三网（支付宝 微信 QQ）设置</div>
	<div class="layui-card-body">
		<form class="layui-form" onsubmit="return false">

			<div class="layui-form-item">
			    <label class="layui-form-label">入口：</label>
				<div class="layui-input-block">
				    <select name="gateway" lay-verify="required">
				      	<option value="0">通用</option>
				        <option value="1">支付宝</option>
				        <option value="2">QQ钱包</option>
				        <option value="3">微信</option>
				    </select>
				</div>
			</div>

			<div class="layui-form-item">
				<label class="layui-form-label" for="codepay_id">码支付ID：</label>
				<div class="layui-input-block">
					<input type="text" name="codepay_id" id="codepay_id" required  lay-verify="required" placeholder="一般为6位纯数字" value="<?php echo get_option("codepay_app_id");?>" autocomplete="off" class="layui-input">
						
				</div>
			</div>

			<div class="layui-form-item">
				<label class="layui-form-label" for="codepay_key">通信秘钥：</label>
				<div class="layui-input-block">
					<input type="text" name="codepay_key" id="codepay_key" required  lay-verify="required" placeholder="请输入通信秘钥" value="<?php echo get_option("codepay_app_key");?>" autocomplete="off" class="layui-input">
						
				</div>
			</div>
			
			<div class="layui-form-item">
			    <label class="layui-form-label">通知地址：</label>
			    <div class="layui-input-block">
			        <input type="text" required lay-verify="required" value="<?php echo home_url()."/wc-api/wc_gateway_freepay";?>" class="layui-input">
			         <div class="layui-form-mid layui-word-aux">请将该通知地址填入codepay后台</div>
			    </div>
			   
			</div>
			
			<div class="layui-form-item">
			    <label class="layui-form-label">跳转地址：</label>
			    <div class="layui-input-block">
			        <input type="text" required lay-verify="required" value="<?php if(get_option("codepay_return_url") == ""){echo home_url()."/my-account/orders";}else{echo get_option("codepay_return_url");}?>" class="layui-input" name="codepay_return_url">
			         <div class="layui-form-mid layui-word-aux">用户支付成功后跳转到该地址</div>
			    </div>
			   
			</div>
			

			<div class="layui-form-item">
				<div class="layui-input-block">
					<button class="layui-btn" lay-submit lay-filter="codepay_keepset">保存</button>
					<button type="reset" class="layui-btn layui-btn-primary">重置</button>
				</div>
			</div>

		</form>
	</div>
</div>
