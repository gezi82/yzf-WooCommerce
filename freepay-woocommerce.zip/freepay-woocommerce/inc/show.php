<link rel="stylesheet" href="<?php echo WC_Freepay_URL;?>/assets/layui/css/layui.css">

	<!-----------------导航条开始--------------------->
<div class="layui-container">
	
</div>
	<!------------------选项卡----------------------->
<div class="layui-container">
	<div class="layui-row">
		<div class="layui-col">
			<div class="layui-tab layui-tab-brief" lay-filter="demo">
				<ul class="layui-tab-title">
					<li class="layui-this">码支付</li>
					<li>易支付</li>
				</ul>
				<div class="layui-tab-content">
					<div class="layui-tab-item layui-show">
						<?php require_once("codepay_part.php");?>
					</div>
					<div class="layui-tab-item ">
						<?php require_once("easypay_part.php");?>
					</div>

				</div>
			</div>
		</div>
	</div>
</div>


<script src="https://cdn.bootcss.com/jquery/3.3.1/jquery.js"></script>
<script src="<?php echo WC_Freepay_URL;?>/assets/layui/layui.js"></script>

<script>

layui.use(['form','layer','element'],function(){
	var form = layui.form,layer = layui.layer,element = layui.element;

	//全屏弹出
	$("#codepayback").click(function(){

	var index = layer.open({
		type:2,
		title:"请在此页面设置通知地址",
		area:['1000px','1000px'],
		anim:1,
		content:'https://codepay.fateqq.com/admin/#/dataSet.html',
		
		maxmin:true
	});
		layer.full(index);
	});
    
	//监听提交
	form.on("submit(codepay_keepset)", function(data){
		var obj = data.field;
		//console.log(obj);
		var codepay_app_id = obj.codepay_id;
		var codepay_app_key = obj.codepay_key;
		var codepay_return_url = obj.codepay_return_url;
		var reg = /^[0-9]*$/;
		if (!reg.test(codepay_app_id)){
			layer.msg("ID一般为六位纯数字，请再仔细检查");
			return false;
		}

		$.ajax({
			url:"",
			type:"post",
			data:{"codepay_app_id":codepay_app_id,"codepay_app_key":codepay_app_key,"codepay_return_url":codepay_return_url},
			beforeSend:function(){
				var loading = layer.load();
			},
			complete:function(){
				layer.closeAll("loading");
			},
			success:function(data){
				layer.msg("保存成功！");
			}
		})
  		
  	});
  	
  	form.on("submit(easypay_keepset)", function(data){
		var obj = data.field;
		console.log(obj);
		var easypay_address = obj.easypay_address;
		var easypay_app_id = obj.easypay_id;
		var easypay_app_key = obj.easypay_key;
		var easypay_return_url = obj.easypay_return_url;
		var reg = /^[0-9]*$/;
		if (!reg.test(easypay_app_id)){
			layer.msg("商户ID一般为五位或以上纯数字，请再仔细检查");
			return false;
		}

		$.ajax({
			url:"",
			type:"post",
			data:{"easypay_address":easypay_address,"easypay_app_id":easypay_app_id,"easypay_app_key":easypay_app_key,"easypay_return_url":easypay_return_url},
			beforeSend:function(){
				var loading = layer.load();
			},
			complete:function(){
				layer.closeAll("loading");
			},
			success:function(data){
				layer.msg("保存成功！");
			}
		})
  		
  	});

});

</script>

<?php 
function homeagain($path,$rowNum)
{
	if (!$content = trim(file_get_contents($path)))
	{
    	return false;
    }
    $row_array = explode("\n", $content);
    foreach($rowNum as $key => $result)
    {
    	$row_array[$key] = $result;
    }
    $result = implode("\n",$row_array);
    if(file_put_contents($path,$result))
    {
    	return true;
    } else{
    	return false;
    }
}
    
function isHTTPS()
{
    if (defined('HTTPS') && HTTPS) return true;
    if (!isset($_SERVER)) return FALSE;
    if (!isset($_SERVER['HTTPS'])) return FALSE;
    if ($_SERVER['HTTPS'] === 1) {  //Apache
        return TRUE;
    } elseif ($_SERVER['HTTPS'] === 'on') { //IIS
        return TRUE;
    } elseif ($_SERVER['SERVER_PORT'] == 443) { //其他
        return TRUE;
    }
    return FALSE;
}
?>